const URL_BASE = 'http://localhost/gestor_bibliotecario/api/';


// Funciones para realizar peticiones

async function getCategorias() {
    const tbody = document.querySelector('#tabla-categorias tbody');
    if (!tbody) {
        return;
    }
    try {
        const response = await fetch(`${URL_BASE}api-categorias.php`);
        const data = await response.json();
        tbody.innerHTML = '';
        data.forEach(categoria => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${categoria.id}</td>
                <td>${categoria.nombre}</td>
                <td>${categoria.descripcion}</td>
                <td>
                    <button class="btn btn-warning btn-sm" onclick="redirigirEditarCategoria(${categoria.id})">Editar</button>
                    <button class="btn btn-danger btn-sm" onclick="eliminarCategoria(${categoria.id})">Eliminar</button>
                </td>
            `;
            tbody.appendChild(tr);
        })
    } catch (error) {
        console.error('Error al obtener las categorías: ', error);
    }
}

async function buscarCategoriaPorNombre(nombre) {
    const tbody = document.querySelector('#tabla-categorias tbody');
    if (!tbody) {
        return;
    }
    try {
        const response = await fetch(`${URL_BASE}api-categorias.php?nombre=${encodeURIComponent(nombre)}`);
        const data = await response.json();
        tbody.innerHTML = '';

        if (response.ok) {
            data.forEach(categoria => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${categoria.id}</td>
                    <td>${categoria.nombre}</td>
                    <td>${categoria.descripcion}</td>
                    <td>
                        <button class="btn btn-warning btn-sm" onclick="redirigirEditarCategoria(${categoria.id})">Editar</button>
                        <button class="btn btn-danger btn-sm" onclick="eliminarCategoria(${categoria.id})">Eliminar</button>
                    </td>
                `;
                tbody.appendChild(tr);
            })
        } else {
            tbody.innerHTML = `
                <tr>
                    <td colspan="4">${data.mensaje || 'No se encontraron categorías'}</td>
                </tr>
            `;
        }
    } catch (error) {
        console.error('Error al buscar la categoría: ', error);
    }
}

// GET ../api/api-categorias.php?id=1 — obtener una por ID
async function getCategoriaPorId(id) {
    try {
        const response = await fetch(`${URL_BASE}api-categorias.php?id=${id}`);
        if (response.ok) {
            const categoria = await response.json();
            return categoria;
        } else {
            console.log('Error al obtener la categoría: ', response.statusText);
        }
    } catch (error) {
        console.error('Error al obtener la categoría: ', error);
    }
}

// POST ../api/api-categorias.php — crear (body: {nombre, descripcion})
async function crearCategoria(nombre, descripcion) {
    try {
        const nuevaCategoria = {
            nombre: nombre,
            descripcion: descripcion
        };
        const response = await fetch(`${URL_BASE}api-categorias.php`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(nuevaCategoria)
        })
        if (response.ok) {
            window.location.replace('index.php'); // Redirige a la página de listado de categorías después de crear una nueva
            return;
        } else {
            const errorData = await response.json().catch(() => null); // Intenta obtener el mensaje de error del cuerpo de la respuesta, si es que existe
            const mensaje = errorData?.mensaje || response.statusText || 'Error al crear la categoría';
            console.log(mensaje);
        }
    } catch (error) {
        console.error('Error al crear la categoría: ', error);
    }
}

// PUT ../api/api-categorias.php?id=1 — actualizar completa (body: {nombre, descripcion})
async function actualizarCategoria(id, nombre, descripcion) {
    const categoriaActualizada = {
        nombre: nombre,
        descripcion: descripcion
    }
    try {
        const response = await fetch(`${URL_BASE}api-categorias.php?id=${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(categoriaActualizada)
        })
        if (response.ok) {
            window.location.replace('index.php'); // Redirige a la página de listado de categorías después de actualizar
            return;
        } else {
            const errorData = await response.json().catch(() => null); // Intenta obtener el mensaje de error del cuerpo de la respuesta, si es que existe
            const mensaje = errorData?.mensaje || response.statusText || 'Error al actualizar la categoría';
            console.log(mensaje);
        }
    } catch (error) {
        console.error('Error al actualizar la categoría: ', error);
    }
}

// DELETE ../api/api-categorias.php?id=1 — eliminar
async function eliminarCategoria(id) {
    try {
        const response = await fetch(`${URL_BASE}api-categorias.php?id=${id}`, {
            method: 'DELETE'
        });
        if (response.ok) {
            window.location.replace('index.php'); // Redirige a la página de listado de categorías después de eliminar
            return;
        } else {
            const errorData = await response.json().catch(() => null); // Intenta obtener el mensaje de error del cuerpo de la respuesta, si es que existe
            const mensaje = errorData?.mensaje || response.statusText || 'Error al eliminar la categoría';
            console.log(mensaje);
        }
    } catch (error) {
        console.error('Error al eliminar la categoría: ', error);
    }
}

// Funciones generales
async function eventoCrearCategoria() {
    const nombre = document.getElementById('nombre').value.trim(); // El método .value obtiene el valor del input con id 'nombre'
    const descripcion = document.getElementById('descripcion').value.trim(); // El método .value obtiene el valor del input con id 'descripcion'
    if (!nombre) {
        console.log('El nombre es obligatorio');
        return;
    }
    await crearCategoria(nombre, descripcion);
}

async function poblarFormularioEdicion(id) {
    const categoria = await getCategoriaPorId(id);
    if (categoria) {
        document.getElementById('nombre').value = categoria.nombre;
        document.getElementById('descripcion').value = categoria.descripcion;
    } else {
        console.log('No se pudo poblar el formulario de edición: categoría no encontrada');
    }
}

async function redirigirEditarCategoria(id) {
    // Redirige a la página de edición con el ID de la categoría como parámetro en la URL
    window.location.href = `edit.php?id=${id}`; // Redirige a la página de edición con el ID de la categoría como parámetro en la URL
}

// Función para obtener el ID de la categoría desde la URL
async function obtenerId() {
    const urlParams = new URLSearchParams(window.location.search);
    const id = urlParams.get('id');
    if (id) {
        return id;
    } else {
        console.log('No se proporcionó un ID de categoría para editar');
        return null;
    }
}

// Llamadas de funciones y eventos
document.addEventListener('DOMContentLoaded', () => {
    getCategorias();
    // Se crea esta variable para almacenar el formulario de alta de categorías y se agrega un listener al evento submit del formulario. Así, cuando se envíe el formulario se manda a llamar a la función eventoCrearCategoria() que se encarga de obtener los valores de los inputs y llamar a la función crearCategoria() para enviar los datos al servidor.
    const categoriaCreateForm = document.getElementById('categoria-create-form');
    const categoriaEditForm = document.getElementById('categoria-edit-form');
    const searchInput = document.getElementById('search-input');

    if (searchInput) {
        searchInput.addEventListener('input', () => {
            const nombre = searchInput.value.trim();
            if (nombre === '') {
                getCategorias();
            } else {
                buscarCategoriaPorNombre(nombre);
            }
        });
    }
    if (categoriaCreateForm) {
        categoriaCreateForm.addEventListener('submit', (event) => {
            event.preventDefault(); // Evita que el formulario se envíe de la manera tradicional
            eventoCrearCategoria();
        });
    }
    if (categoriaEditForm) {
        obtenerId().then((id) => { // Llama a la función obtenerId() para obtener el ID de la categoría desde la URL y luego llama a poblarFormularioEdicion(id) para llenar el formulario con los datos de la categoría correspondiente.
            if (id) {
                poblarFormularioEdicion(id);
            } else {
                console.log('No se proporcionó un ID de categoría para editar');
            }
        });
        categoriaEditForm.addEventListener('submit', (event) => {
            event.preventDefault();
            const nombre = document.getElementById('nombre').value.trim();
            const descripcion = document.getElementById('descripcion').value.trim();
            obtenerId().then((id) => { // Llama a la función obtenerId() para obtener el ID de la categoría desde la URL y luego llama a actualizarCategoria(id, nombre, descripcion) para enviar los datos actualizados al servidor.
                if (id) {
                    actualizarCategoria(id, nombre, descripcion);
                } else {
                    console.log('No se proporcionó un ID de categoría para actualizar');
                }
            });
        });
    }

});
