<?php
require_once('../config/connection.php');

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'OPTIONS') {
    http_response_code(200);
    echo json_encode(array("mensaje" => "Preflight OK"));
    $conn->close();
    exit;
}

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("SELECT id, id_prestamo, id_libro, cantidad FROM detalle_prestamo WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $resultado = $stmt->get_result();

            if ($resultado->num_rows > 0) {
                http_response_code(200);
                echo json_encode($resultado->fetch_assoc());
            } else {
                http_response_code(404);
                echo json_encode(array("mensaje" => "Detalle de prestamo no encontrado"));
            }
            $stmt->close();
        } elseif (isset($_GET['prestamo'])) {
            $id_prestamo = intval($_GET['prestamo']);
            $stmt = $conn->prepare("SELECT id, id_prestamo, id_libro, cantidad FROM detalle_prestamo WHERE id_prestamo = ? ORDER BY id");
            $stmt->bind_param("i", $id_prestamo);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $detalles = array();

            while ($row = $resultado->fetch_assoc()) {
                $detalles[] = $row;
            }

            http_response_code(200);
            echo json_encode($detalles);
            $stmt->close();
        } elseif (isset($_GET['libro'])) {
            $id_libro = intval($_GET['libro']);
            $stmt = $conn->prepare("SELECT id, id_prestamo, id_libro, cantidad FROM detalle_prestamo WHERE id_libro = ? ORDER BY id");
            $stmt->bind_param("i", $id_libro);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $detalles = array();

            while ($row = $resultado->fetch_assoc()) {
                $detalles[] = $row;
            }

            http_response_code(200);
            echo json_encode($detalles);
            $stmt->close();
        } elseif (isset($_GET['id_libro'])) {
            $id_libro = intval($_GET['id_libro']);
            $con_libro = isset($_GET['con_libro']) && strtolower(trim($_GET['con_libro'])) === 'true';

            if ($con_libro) {
                $stmt = $conn->prepare("SELECT detalle_prestamo.id, detalle_prestamo.id_prestamo, detalle_prestamo.id_libro, detalle_prestamo.cantidad, libros.titulo, libros.isbn FROM detalle_prestamo INNER JOIN libros ON detalle_prestamo.id_libro = libros.id WHERE detalle_prestamo.id_libro = ? ORDER BY detalle_prestamo.id");
            } else {
                $stmt = $conn->prepare("SELECT id, id_prestamo, id_libro, cantidad FROM detalle_prestamo WHERE id_libro = ? ORDER BY id");
            }

            $stmt->bind_param("i", $id_libro);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $detalles = array();

            while ($row = $resultado->fetch_assoc()) {
                $detalles[] = $row;
            }

            http_response_code(200);
            echo json_encode($detalles);
            $stmt->close();
        } else {
            $stmt = $conn->prepare("SELECT id, id_prestamo, id_libro, cantidad FROM detalle_prestamo ORDER BY id");
            $stmt->execute();
            $resultado = $stmt->get_result();
            $detalles = array();

            while ($row = $resultado->fetch_assoc()) {
                $detalles[] = $row;
            }

            http_response_code(200);
            echo json_encode($detalles);
            $stmt->close();
        }
        $conn->close();
        break;

    default:
        http_response_code(405);
        echo json_encode(array("mensaje" => "Metodo no permitido"));
        $conn->close();
        break;
}
