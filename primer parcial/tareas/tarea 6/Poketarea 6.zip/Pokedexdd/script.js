const TYPE_COLORS = {
  fire:'#F08030',grass:'#78C850',water:'#6890F0',electric:'#F8D030',
  psychic:'#F85888',ice:'#98D8D8',dragon:'#7038F8',dark:'#705848',
  fairy:'#EE99AC',normal:'#A8A878',fighting:'#C03028',flying:'#A890F0',
  poison:'#A040A0',ground:'#E0C068',rock:'#B8A038',bug:'#A8B820',
  ghost:'#705898',steel:'#B8B8D0',
};
const TYPE_TEXT = {
  fire:'#7a3000',grass:'#2d5a00',water:'#1a3d7a',electric:'#7a6000',
  psychic:'#7a0030',ice:'#1a6060',dragon:'#2a007a',dark:'#ffffff',
  fairy:'#7a1040',normal:'#3a3830',fighting:'#600000',flying:'#3a2870',
  poison:'#3a0050',ground:'#5a4000',rock:'#4a3800',bug:'#3a4500',
  ghost:'#2a1a50',steel:'#3a3a50',
};

const grid = document.getElementById('grid');
const status = document.getElementById('status');
const errorMsg = document.getElementById('error-msg');
const modalBg = document.getElementById('modal-bg');
const modalBody = document.getElementById('modal-body');

async function fetchJSON(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error('No encontrado');
  return res.json();
}

function typeBadge(type) {
  const bg = TYPE_COLORS[type] || '#888';
  const col = TYPE_TEXT[type] || '#fff';
  return `<span class="type-badge" style="background:${bg};color:${col}">${type}</span>`;
}

function statBar(name, value) {
  const pct = Math.min(100, Math.round(value / 255 * 100));
  return `<div class="stat-row">
    <span class="stat-name">${name}</span>
    <div class="stat-bar-bg"><div class="stat-bar" style="width:${pct}%"></div></div>
    <span class="stat-val">${value}</span>
  </div>`;
}

function renderCard(pokemon) {
  const types = pokemon.types.map(t => t.type.name);
  const img = pokemon.sprites.front_default || '';
  const num = String(pokemon.id).padStart(3, '0');
  const card = document.createElement('div');
  card.className = 'card';
  card.innerHTML = `
    <img src="${img}" alt="${pokemon.name}" loading="lazy" />
    <div class="num">#${num}</div>
    <div class="name">${pokemon.name}</div>
    <div class="types">${types.map(typeBadge).join('')}</div>
  `;
  card.addEventListener('click', () => openModal(pokemon));
  return card;
}

function openModal(pokemon) {
  const types = pokemon.types.map(t => t.type.name);
  const img = pokemon.sprites.other?.['official-artwork']?.front_default || pokemon.sprites.front_default || '';
  const num = String(pokemon.id).padStart(3, '0');
  const stats = pokemon.stats.map(s => statBar(s.stat.name, s.base_stat)).join('');
  const ht = (pokemon.height / 10).toFixed(1);
  const wt = (pokemon.weight / 10).toFixed(1);
  modalBody.innerHTML = `
    <img src="${img}" alt="${pokemon.name}" />
    <h2>${pokemon.name}</h2>
    <div class="mid">#${num} &nbsp;|&nbsp; ${ht} m &nbsp;|&nbsp; ${wt} kg</div>
    <div class="types" style="justify-content:center;margin-bottom:12px">${types.map(typeBadge).join('')}</div>
    <div class="stats">${stats}</div>
  `;
  modalBg.classList.add('open');
}

document.getElementById('modal-close').addEventListener('click', () => modalBg.classList.remove('open'));
modalBg.addEventListener('click', e => { if (e.target === modalBg) modalBg.classList.remove('open'); });

async function loadList() {
  errorMsg.textContent = '';
  try {
    const data = await fetchJSON('https://pokeapi.co/api/v2/pokemon?limit=20&offset=0');
    const promises = data.results.map(p => fetchJSON(p.url));
    const pokemons = await Promise.all(promises);
    grid.innerHTML = '';
    pokemons.forEach(p => grid.appendChild(renderCard(p)));
    status.textContent = `Mostrando ${pokemons.length} Pokémon`;
  } catch (e) {
    status.textContent = '';
    errorMsg.textContent = 'Error al cargar la lista. Intenta de nuevo.';
  }
}

async function searchPokemon() {
  const query = document.getElementById('search-input').value.trim().toLowerCase();
  if (!query) { loadList(); return; }
  status.textContent = 'Buscando...';
  errorMsg.textContent = '';
  grid.innerHTML = '';
  try {
    const pokemon = await fetchJSON(`https://pokeapi.co/api/v2/pokemon/${query}`);
    grid.appendChild(renderCard(pokemon));
    status.textContent = `Resultado para "${query}"`;
  } catch (e) {
    status.textContent = '';
    errorMsg.textContent = `No se encontro "${query}". Verifica el nombre o número.`;
  }
}

document.getElementById('search-btn').addEventListener('click', searchPokemon);
document.getElementById('search-input').addEventListener('keydown', e => {
  if (e.key === 'Enter') searchPokemon();
});

loadList();
